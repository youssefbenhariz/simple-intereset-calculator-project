# Simple Interest calculator
